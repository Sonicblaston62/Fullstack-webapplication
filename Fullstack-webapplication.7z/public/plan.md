Jeg skal lage en Steam lignenede online spillbutikk.. Hvor du kan se forhåndsvisning, beskrivelse, pris og vurdering a spillet på lignenede måte som du kan på steam
nettsiden skal ha en hovedide hvor du får en liste med forskjellige spill som du kan velge mellom. nettsiden vil laste denne informasjonen fra sereren. Du vil kunne trykke inn på hvert spill hvor du får en egen storepage med mer info om spillet inkludert beskrivelse, coverart, spillvurdering og utvikler a programmet. 
Jeg begynner med frontenden og starter med å lage et gridlayout for spillenen. så kan tittlen til spillet stå under. 
jeg lager den egne storepagen som du vil se når du trykker inn på et spill. all data vil bli hentet fra databasen som blir laget senere.
så kan jeg lage database som skal kobles opp til dette der vil hvert spill sin data være lagret. Det vil si bilder, beskrivelse, vurdering og utvikler
